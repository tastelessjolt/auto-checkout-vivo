console.log ("Activate xD");

document.body.style.border = "5px solid red";

var ks_form = document.getElementById("formVerify");
var ks_keywords = ks_form.getElementsByTagName("span");
var keywords = []
keywords[0] = ks_keywords[0].innerText;
keywords[1] = ks_keywords[1].innerText;

var ks_imgs = ks_form.getElementsByTagName("img");

for (var ind in ks_imgs) {
	ks_imgs[ind].onclick = callback;
	// ks_imgs[ind].addEventListener("click", callback);
	console.log(ks_imgs[ind].onclick);
}

var global_mapping = {};
var state = 0;

function loadJSON(path, success, error)
{
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function()
    {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                if (success)
                    success(JSON.parse(xhr.responseText));
            } else {
                if (error)
                    error(xhr);
            }
        }
    };
    xhr.open("GET", path, true);
    xhr.send();
}

function onGot(item) {
	console.log(item["mapping"]);

	try {
		var mapping = JSON.parse(JSON.stringify(item["mapping"]));
		global_mapping = mapping;
		console.log(mapping);
	}
	catch (e) {
		var url = browser.extension.getURL("content/learnt.json");
		console.log(url);
		loadJSON(url, function(data) {global_mapping = data; console.log(data);}, function(xhr) {console.log(xhr); })		
	}
	

	
	if (keywords[0] in mapping) {
		for (var key in ks_imgs) {
			if (ks_imgs[key].getAttribute("src") === mapping[keywords[0]]) {
				ks_imgs[key].click();
				if (keywords[1] in mapping) {
					for (var key in ks_imgs) {
						if (ks_imgs[key].getAttribute("src") === mapping[keywords[1]]) {
							ks_imgs[key].click();
							break;
						}
					}
				}
				break;
			}
		}
	}
}

function onError(error) {
  console.log(`Error: ${error}`);
}

function callback(event) {
	console.log(event);
	var img = event.target;
	var src = img.getAttribute("src");

	if (keywords[state] in global_mapping) {
		console.log(`Found: ${global_mapping[keywords[state]]}`);
		console.log(`Selected: ${src}`);
	}
	else {
		console.log("Not found. Adding...");
		global_mapping[keywords[state]] = src;
		console.log(global_mapping);
	}



	state = state + 1;

	let setting = browser.storage.local.set({"mapping" : global_mapping});
	// let setting = browser.storage.local.set("random");
	// // just check for errors
	setting.then(null, onError);

	if (state === 1) {
		if (keywords[1] in global_mapping) {
			for (var key in ks_imgs) {
				if (ks_imgs[key].getAttribute("src") === global_mapping[keywords[1]]) {
					ks_imgs[key].click();
					break;
				}
			}
		}
	}
}

let gettingItem = browser.storage.local.get();
	gettingItem.then(onGot, onError);


// let setting = browser.storage.local.set({"mapping": {"hello": "Adf"}});
// just check for errors
// setting.then(null, onError);
